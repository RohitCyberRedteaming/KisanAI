import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Platform, RefreshControl,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../constants/Colors';
import { useApp } from '../../contexts/AppContext';
import { Card, SectionHeader, StatCard } from '../../components/UI';
import { CROPS, WEATHER_FORECAST } from '../../constants/Data';

const ALERTS = [
  { id: '1', type: 'danger', icon: '🌧️', title: 'कल भारी बारिश संभव', sub: 'सिंचाई और खाद डालना टालें। फसल सुरक्षित रखें।' },
  { id: '2', type: 'warn', icon: '🐛', title: 'कीट प्रकोप का खतरा', sub: 'आपके क्षेत्र में सफेद मक्खी रिपोर्ट हुई है।' },
  { id: '3', type: 'info', icon: '📈', title: 'सोयाबीन की कीमत बढ़ी', sub: 'आज मंडी में ₹250/क्विंटल वृद्धि। बेचने का समय!' },
];

export default function HomeScreen() {
  const { scanHistory, farmerName, farmerLocation } = useApp();
  const [refreshing, setRefreshing] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1000));
    setRefreshing(false);
  };

  const greeting = () => {
    const h = time.getHours();
    if (h < 12) return 'सुप्रभात 🌅';
    if (h < 17) return 'नमस्ते ☀️';
    return 'शुभ संध्या 🌙';
  };

  const alertColor = (type: string) => ({
    danger: { left: Colors.danger, bg: '#fce4ec' },
    warn: { left: Colors.gold, bg: '#fff8e1' },
    info: { left: Colors.secondary, bg: '#e3f2fd' },
  }[type] || { left: Colors.primary, bg: Colors.primaryBg });

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={[Colors.darkMid, Colors.dark]}
        style={styles.header}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>{greeting()}</Text>
            <Text style={styles.farmerName}>{farmerName}</Text>
            <Text style={styles.farmerLoc}>📍 {farmerLocation}</Text>
          </View>
          <TouchableOpacity style={styles.notifBtn} onPress={() => {}}>
            <Text style={{ fontSize: 22 }}>🔔</Text>
            <View style={styles.notifDot} />
          </TouchableOpacity>
        </View>

        {/* Weather mini card */}
        <TouchableOpacity
          style={styles.weatherMini}
          onPress={() => router.push('/(tabs)/weather')}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ fontSize: 32 }}>⛅</Text>
            <View>
              <Text style={styles.weatherTemp}>32°C</Text>
              <Text style={styles.weatherDesc}>आंशिक बादल · 68% नमी</Text>
            </View>
          </View>
          <View style={styles.weatherBadge}>
            <Text style={{ fontSize: 12, color: Colors.gold, fontWeight: '700' }}>
              🌧️ कल बारिश 75%
            </Text>
          </View>
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[Colors.primary]} />
        }
      >
        {/* Stat Row */}
        <View style={styles.statRow}>
          <StatCard
            icon="🌾"
            value="3"
            label="सक्रिय फसलें"
            iconBg={Colors.primaryBg}
            onPress={() => router.push('/(tabs)/more')}
          />
          <StatCard
            icon="🔬"
            value={String(scanHistory.length || 12)}
            label="कुल स्कैन"
            iconBg="#e3f2fd"
            onPress={() => router.push('/(tabs)/scan')}
          />
          <StatCard
            icon="💰"
            value="₹4,200"
            label="गेहूँ/क्विंटल"
            iconBg={Colors.goldBg}
            onPress={() => router.push('/(tabs)/market')}
          />
        </View>

        {/* Quick Actions */}
        <SectionHeader title="⚡ त्वरित क्रिया" />
        <View style={styles.quickGrid}>
          {[
            { icon: '📸', label: 'फसल स्कैन करें', color: Colors.primary, route: '/camera' },
            { icon: '🌱', label: 'फसल सुझाव', color: Colors.secondary, route: '/(tabs)/more' },
            { icon: '🤖', label: 'AI चैटबॉट', color: '#8b5cf6', route: '/chat' },
            { icon: '👥', label: 'किसान समुदाय', color: Colors.earth, route: '/(tabs)/more' },
          ].map((item) => (
            <TouchableOpacity
              key={item.label}
              style={[styles.quickBtn, { borderColor: item.color + '40' }]}
              onPress={() => router.push(item.route as any)}
              activeOpacity={0.8}
            >
              <View style={[styles.quickIcon, { backgroundColor: item.color + '20' }]}>
                <Text style={{ fontSize: 26 }}>{item.icon}</Text>
              </View>
              <Text style={[styles.quickLabel, { color: item.color }]}>{item.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Alerts */}
        <SectionHeader title="🚨 ताज़े अलर्ट" action="सभी" onAction={() => {}} />
        <View style={{ gap: 10, marginBottom: 20 }}>
          {ALERTS.map((a) => {
            const c = alertColor(a.type);
            return (
              <View key={a.id} style={[styles.alertItem, { backgroundColor: c.bg, borderLeftColor: c.left }]}>
                <Text style={{ fontSize: 22 }}>{a.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.alertTitle}>{a.title}</Text>
                  <Text style={styles.alertSub}>{a.sub}</Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* Market preview */}
        <SectionHeader title="📊 आज के मंडी भाव" action="सभी देखें" onAction={() => router.push('/(tabs)/market')} />
        <Card>
          {CROPS.slice(0, 4).map((crop, i) => (
            <View key={crop.id}>
              <View style={styles.marketRow}>
                <Text style={{ fontSize: 20 }}>{crop.emoji}</Text>
                <Text style={styles.cropName}>{crop.name}</Text>
                <Text style={styles.cropPrice}>₹{crop.price.toLocaleString('hi-IN')}</Text>
                <View style={[
                  styles.trendBadge,
                  { backgroundColor: crop.trend === 'up' ? Colors.successBg : Colors.dangerBg }
                ]}>
                  <Text style={{
                    fontSize: 12,
                    fontWeight: '800',
                    color: crop.trend === 'up' ? Colors.success : Colors.danger,
                  }}>
                    {crop.trend === 'up' ? '▲' : '▼'} {crop.change}%
                  </Text>
                </View>
              </View>
              {i < 3 && <View style={styles.rowDivider} />}
            </View>
          ))}
        </Card>

        {/* 5-day forecast strip */}
        <SectionHeader title="🌤️ 5-दिन मौसम" action="विस्तार" onAction={() => router.push('/(tabs)/weather')} style={{ marginTop: 20 }} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 24 }}>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {WEATHER_FORECAST.map((d, i) => (
              <View key={i} style={styles.forecastCard}>
                <Text style={styles.forecastDay}>{d.day}</Text>
                <Text style={{ fontSize: 26 }}>{d.icon}</Text>
                <Text style={styles.forecastTemp}>{d.temp}°C</Text>
                <Text style={styles.forecastRain}>🌧 {d.rain}%</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingTop: Platform.OS === 'ios' ? 54 : 32,
    paddingHorizontal: 18,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  greeting: { fontSize: 14, color: 'rgba(255,255,255,.6)', fontWeight: '600' },
  farmerName: { fontSize: 22, fontWeight: '800', color: '#fff', marginTop: 2 },
  farmerLoc: { fontSize: 13, color: 'rgba(255,255,255,.55)', marginTop: 2 },
  notifBtn: { position: 'relative', padding: 4 },
  notifDot: {
    position: 'absolute', top: 4, right: 4,
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: Colors.danger, borderWidth: 1.5, borderColor: Colors.dark,
  },
  weatherMini: {
    backgroundColor: 'rgba(255,255,255,.12)',
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,.15)',
  },
  weatherTemp: { fontSize: 20, fontWeight: '800', color: '#fff' },
  weatherDesc: { fontSize: 12, color: 'rgba(255,255,255,.7)', marginTop: 2 },
  weatherBadge: {
    backgroundColor: 'rgba(244,185,66,.15)',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 32 },
  statRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  quickBtn: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1.5,
    gap: 8,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
  },
  quickIcon: { width: 52, height: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  quickLabel: { fontSize: 13, fontWeight: '700', textAlign: 'center' },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderLeftWidth: 4,
  },
  alertTitle: { fontSize: 14, fontWeight: '700', color: Colors.textPrimary, marginBottom: 2 },
  alertSub: { fontSize: 12, color: Colors.textSecondary, lineHeight: 17 },
  marketRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8 },
  cropName: { flex: 1, fontSize: 14, fontWeight: '600', color: Colors.textPrimary },
  cropPrice: { fontSize: 15, fontWeight: '800', color: Colors.textPrimary },
  trendBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  rowDivider: { height: 1, backgroundColor: Colors.border },
  forecastCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 4,
    width: 80,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  forecastDay: { fontSize: 12, color: Colors.textMuted, fontWeight: '700' },
  forecastTemp: { fontSize: 16, fontWeight: '800', color: Colors.textPrimary },
  forecastRain: { fontSize: 11, color: Colors.secondary },
});
