import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Platform, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../constants/Colors';
import { Card, SectionHeader } from '../../components/UI';
import { WEATHER_FORECAST } from '../../constants/Data';

const WEATHER_DATA = {
  location: 'लखनऊ, उत्तर प्रदेश',
  temp: 32,
  feelsLike: 36,
  humidity: 68,
  wind: 14,
  desc: 'आंशिक बादल',
  icon: '⛅',
  uvIndex: 7,
  visibility: 8,
};

const ADVISORIES = [
  {
    icon: '✅',
    title: 'आज करें',
    color: Colors.primary,
    bg: Colors.primaryBg,
    items: ['सिंचाई करें', 'कटाई पूरी करें', 'फसल ढकें', 'बीजोपचार करें'],
  },
  {
    icon: '❌',
    title: 'कल न करें',
    color: Colors.danger,
    bg: Colors.dangerBg,
    items: ['खाद न डालें', 'कीटनाशक नहीं', 'कटाई टालें'],
  },
  {
    icon: '🌱',
    title: 'फसल सलाह',
    color: Colors.secondary,
    bg: Colors.secondaryBg,
    body: 'इस सप्ताह तापमान 27-35°C रहेगा। गेहूँ के लिए आदर्श। रबी की बुआई के लिए अगला सोमवार उत्तम है।',
  },
  {
    icon: '💧',
    title: 'सिंचाई गाइड',
    color: Colors.secondary,
    bg: Colors.secondaryBg,
    body: 'कल बारिश के कारण बुधवार तक सिंचाई की जरूरत नहीं। मिट्टी की नमी 70%+ रहेगी।',
  },
];

export default function WeatherScreen() {
  const [loading, setLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState(
    '💡 AI सलाह: आज सिंचाई करें — कल दोपहर 3 बजे से बारिश की संभावना 75% है। खाद डालना कल तक टालें।'
  );

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Main Weather Card */}
        <LinearGradient
          colors={['#1565c0', '#1a7abf', '#00acc1']}
          style={styles.mainWeather}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Text style={styles.location}>📍 {WEATHER_DATA.location}</Text>
          <View style={styles.tempRow}>
            <Text style={styles.temp}>{WEATHER_DATA.temp}°C</Text>
            <Text style={{ fontSize: 72 }}>{WEATHER_DATA.icon}</Text>
          </View>
          <Text style={styles.desc}>
            {WEATHER_DATA.desc} · 体感 {WEATHER_DATA.feelsLike}°C
          </Text>

          <View style={styles.weatherStats}>
            {[
              { icon: '💧', label: 'नमी', val: `${WEATHER_DATA.humidity}%` },
              { icon: '💨', label: 'हवा', val: `${WEATHER_DATA.wind} km/h` },
              { icon: '☀️', label: 'UV Index', val: String(WEATHER_DATA.uvIndex) },
              { icon: '👁️', label: 'दृश्यता', val: `${WEATHER_DATA.visibility} km` },
            ].map((s) => (
              <View key={s.label} style={styles.weatherStat}>
                <Text style={{ fontSize: 18 }}>{s.icon}</Text>
                <Text style={styles.statVal}>{s.val}</Text>
                <Text style={styles.statLbl}>{s.label}</Text>
              </View>
            ))}
          </View>

          {/* AI Advisory inline */}
          <View style={styles.aiAdvisory}>
            <Text style={{ fontSize: 16 }}>🤖</Text>
            <Text style={styles.aiAdvisoryText}>{aiAdvice}</Text>
          </View>
        </LinearGradient>

        {/* 5-day forecast */}
        <SectionHeader title="📅 5-दिन का पूर्वानुमान" style={styles.sectionPad} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingLeft: 16 }}>
          <View style={{ flexDirection: 'row', gap: 10, paddingRight: 16 }}>
            {WEATHER_FORECAST.map((d, i) => (
              <View key={i} style={[styles.forecastCard, i === 0 && styles.forecastToday]}>
                <Text style={[styles.forecastDay, i === 0 && { color: Colors.primary }]}>{d.day}</Text>
                <Text style={{ fontSize: 28 }}>{d.icon}</Text>
                <Text style={styles.forecastTemp}>{d.temp}°C</Text>
                <View style={styles.rainBadge}>
                  <Text style={styles.rainText}>🌧 {d.rain}%</Text>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Advisory cards */}
        <View style={styles.sectionPad}>
          <SectionHeader title="🌾 खेती सलाह" />
          <View style={styles.advisoryGrid}>
            {ADVISORIES.map((a) => (
              <Card key={a.title} style={{ backgroundColor: a.bg, borderColor: a.color + '30' }}>
                <View style={styles.advisoryHead}>
                  <Text style={{ fontSize: 18 }}>{a.icon}</Text>
                  <Text style={[styles.advisoryTitle, { color: a.color }]}>{a.title}</Text>
                </View>
                {a.items ? (
                  <View style={{ gap: 6, marginTop: 8 }}>
                    {a.items.map((item) => (
                      <View key={item} style={styles.advisoryItem}>
                        <Text style={[styles.advisoryTag, { backgroundColor: a.color + '20', color: a.color }]}>
                          {item}
                        </Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <Text style={styles.advisoryBody}>{a.body}</Text>
                )}
              </Card>
            ))}
          </View>
        </View>

        {/* Pest risk */}
        <View style={[styles.sectionPad, { paddingBottom: 90 }]}>
          <SectionHeader title="🐛 कीट जोखिम" />
          <Card>
            {[
              { name: 'सफेद मक्खी', risk: 'उच्च', pct: 80, color: Colors.danger },
              { name: 'टिड्डी', risk: 'मध्यम', pct: 45, color: Colors.gold },
              { name: 'माहू (Aphid)', risk: 'कम', pct: 20, color: Colors.primary },
            ].map((p) => (
              <View key={p.name} style={styles.pestRow}>
                <Text style={styles.pestName}>{p.name}</Text>
                <View style={styles.pestBarBg}>
                  <View style={[styles.pestBarFill, { width: `${p.pct}%` as any, backgroundColor: p.color }]} />
                </View>
                <Text style={[styles.pestRisk, { color: p.color }]}>{p.risk}</Text>
              </View>
            ))}
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingBottom: 20 },
  mainWeather: {
    paddingTop: Platform.OS === 'ios' ? 54 : 36,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  location: { fontSize: 14, color: 'rgba(255,255,255,.75)', fontWeight: '600' },
  tempRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 4 },
  temp: { fontSize: 80, fontWeight: '800', color: '#fff', lineHeight: 88 },
  desc: { fontSize: 16, color: 'rgba(255,255,255,.85)', marginTop: 4 },
  weatherStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,.12)',
    borderRadius: 14,
    padding: 14,
    marginTop: 18,
  },
  weatherStat: { alignItems: 'center', gap: 3 },
  statVal: { fontSize: 14, fontWeight: '800', color: '#fff' },
  statLbl: { fontSize: 10, color: 'rgba(255,255,255,.6)', fontWeight: '600' },
  aiAdvisory: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    backgroundColor: 'rgba(255,255,255,.15)',
    borderRadius: 12,
    padding: 12,
    marginTop: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,.2)',
  },
  aiAdvisoryText: { flex: 1, fontSize: 13, color: '#fff', fontWeight: '600', lineHeight: 18 },
  sectionPad: { paddingHorizontal: 16, marginTop: 20 },
  forecastCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 6,
    width: 86,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  forecastToday: { borderColor: Colors.primary, borderWidth: 2 },
  forecastDay: { fontSize: 12, color: Colors.textMuted, fontWeight: '700' },
  forecastTemp: { fontSize: 17, fontWeight: '800', color: Colors.textPrimary },
  rainBadge: { backgroundColor: '#e3f2fd', borderRadius: 8, paddingHorizontal: 6, paddingVertical: 2 },
  rainText: { fontSize: 11, color: Colors.secondary, fontWeight: '700' },
  advisoryGrid: { gap: 12 },
  advisoryHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  advisoryTitle: { fontSize: 15, fontWeight: '800' },
  advisoryItem: { flexDirection: 'row' },
  advisoryTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, fontSize: 12, fontWeight: '700' },
  advisoryBody: { fontSize: 13, color: Colors.textSecondary, lineHeight: 19, marginTop: 8 },
  pestRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10 },
  pestName: { width: 100, fontSize: 13, fontWeight: '600', color: Colors.textPrimary },
  pestBarBg: { flex: 1, height: 8, backgroundColor: Colors.border, borderRadius: 20, overflow: 'hidden' },
  pestBarFill: { height: '100%', borderRadius: 20 },
  pestRisk: { width: 45, fontSize: 12, fontWeight: '700', textAlign: 'right' },
});
