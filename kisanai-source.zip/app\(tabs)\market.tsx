import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Platform, TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../constants/Colors';
import { Card, SectionHeader } from '../../components/UI';
import { CROPS } from '../../constants/Data';

const MANDIS = ['लखनऊ मंडी', 'कानपुर मंडी', 'वाराणसी मंडी', 'आगरा मंडी', 'इलाहाबाद मंडी'];

export default function MarketScreen() {
  const [search, setSearch] = useState('');
  const [selectedMandi, setSelectedMandi] = useState('लखनऊ मंडी');
  const [showMandi, setShowMandi] = useState(false);

  const filtered = CROPS.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  const AI_ADVICE = `🤖 AI मंडी सलाह: गेहूँ और मूँगफली की कीमतें इस हफ्ते बढ़ रही हैं। गेहूँ अभी बेचें — कल बारिश के बाद गुणवत्ता प्रभावित हो सकती है। मक्का के लिए 2-3 दिन प्रतीक्षा करें।`;

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={[Colors.darkMid, Colors.dark]} style={styles.header}>
        <Text style={styles.headerTitle}>📊 मंडी भाव</Text>
        <TouchableOpacity style={styles.mandiSelect} onPress={() => setShowMandi(!showMandi)}>
          <Text style={styles.mandiText}>📍 {selectedMandi}</Text>
          <Text style={styles.mandiCaret}>▾</Text>
        </TouchableOpacity>
        {showMandi && (
          <View style={styles.mandiDropdown}>
            {MANDIS.map((m) => (
              <TouchableOpacity
                key={m}
                style={[styles.mandiOption, m === selectedMandi && styles.mandiOptionActive]}
                onPress={() => { setSelectedMandi(m); setShowMandi(false); }}
              >
                <Text style={[styles.mandiOptionText, m === selectedMandi && { color: Colors.primary }]}>{m}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </LinearGradient>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <>
            {/* Search */}
            <View style={styles.searchBox}>
              <Text style={{ fontSize: 16 }}>🔍</Text>
              <TextInput
                style={styles.searchInput}
                placeholder="फसल खोजें... (गेहूँ, धान, मक्का)"
                value={search}
                onChangeText={setSearch}
                placeholderTextColor={Colors.textMuted}
              />
            </View>

            {/* Summary row */}
            <View style={styles.summaryRow}>
              {[
                { icon: '📈', label: 'बढ़त', count: CROPS.filter(c=>c.trend==='up').length, color: Colors.primary },
                { icon: '📉', label: 'गिरावट', count: CROPS.filter(c=>c.trend==='down').length, color: Colors.danger },
                { icon: '🏷️', label: 'कुल फसल', count: CROPS.length, color: Colors.secondary },
              ].map((s) => (
                <View key={s.label} style={[styles.summaryCard, { borderColor: s.color + '30' }]}>
                  <Text style={{ fontSize: 20 }}>{s.icon}</Text>
                  <Text style={[styles.summaryCount, { color: s.color }]}>{s.count}</Text>
                  <Text style={styles.summaryLabel}>{s.label}</Text>
                </View>
              ))}
            </View>

            <SectionHeader title="🌾 आज के भाव" style={{ paddingHorizontal: 16, marginTop: 4 }} />
          </>
        }
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.cropCard} activeOpacity={0.85}>
            <Text style={{ fontSize: 32 }}>{item.emoji}</Text>
            <View style={styles.cropInfo}>
              <Text style={styles.cropName}>{item.name}</Text>
              <Text style={styles.cropSeason}>मौसम: {item.season}</Text>
            </View>
            <View style={styles.priceBlock}>
              <Text style={styles.priceVal}>₹{item.price.toLocaleString('hi-IN')}</Text>
              <Text style={styles.priceUnit}>/क्विंटल</Text>
              <View style={[
                styles.changeBadge,
                { backgroundColor: item.trend === 'up' ? Colors.successBg : Colors.dangerBg }
              ]}>
                <Text style={[styles.changeText, { color: item.trend === 'up' ? Colors.success : Colors.danger }]}>
                  {item.trend === 'up' ? '▲' : '▼'} {item.change}%
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={{ paddingBottom: 20 }}
        ListFooterComponent={
          <View style={styles.aiBox}>
            <Text style={{ fontSize: 22 }}>🤖</Text>
            <Text style={styles.aiText}>{AI_ADVICE}</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingTop: Platform.OS === 'ios' ? 54 : 32,
    paddingHorizontal: 18,
    paddingBottom: 20,
  },
  headerTitle: { fontSize: 24, fontWeight: '800', color: '#fff', marginBottom: 12 },
  mandiSelect: {
    backgroundColor: 'rgba(255,255,255,.15)',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,.2)',
  },
  mandiText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  mandiCaret: { color: '#fff', fontSize: 16 },
  mandiDropdown: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginTop: 6,
    overflow: 'hidden',
    elevation: 8,
    zIndex: 100,
  },
  mandiOption: { paddingHorizontal: 16, paddingVertical: 13 },
  mandiOptionActive: { backgroundColor: Colors.primaryBg },
  mandiOptionText: { fontSize: 14, fontWeight: '600', color: Colors.textPrimary },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 10,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  searchInput: { flex: 1, fontSize: 14, color: Colors.textPrimary },
  summaryRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1.5,
  },
  summaryCount: { fontSize: 20, fontWeight: '800' },
  summaryLabel: { fontSize: 11, color: Colors.textMuted, fontWeight: '600' },
  cropCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  cropInfo: { flex: 1 },
  cropName: { fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  cropSeason: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  priceBlock: { alignItems: 'flex-end', gap: 3 },
  priceVal: { fontSize: 18, fontWeight: '800', color: Colors.textPrimary },
  priceUnit: { fontSize: 11, color: Colors.textMuted },
  changeBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  changeText: { fontSize: 12, fontWeight: '800' },
  separator: { height: 1, backgroundColor: Colors.border, marginHorizontal: 16 },
  aiBox: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
    backgroundColor: Colors.primaryBg,
    margin: 16,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 80,
  },
  aiText: { flex: 1, fontSize: 14, color: Colors.primaryDark, lineHeight: 20 },
});
