import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Platform, KeyboardAvoidingView, ActivityIndicator,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Speech from 'expo-speech';
import { Colors } from '../constants/Colors';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  time: string;
}

const QUICK_QUESTIONS = [
  'मेरी फसल में पीले पत्ते हो रहे हैं?',
  'गेहूँ में कौन सी खाद डालूँ?',
  'सफेद मक्खी का कीटनाशक बताएं',
  'PM-KISAN योजना क्या है?',
  'कल बारिश है, क्या सिंचाई करूँ?',
];

const SYSTEM_PROMPT = `आप KisanAI हैं — एक भारतीय कृषि विशेषज्ञ AI। आप किसानों को हिंदी में सरल, व्यावहारिक सलाह देते हैं। विषय: फसल रोग, मौसम, खाद, कीट, मंडी भाव, सरकारी योजनाएँ। जवाब 3-5 वाक्यों में दें, इमोजी का उपयोग करें।`;

export default function ChatScreen() {
  const params = useLocalSearchParams();
  const disease = params.disease as string;
  const symptoms = params.symptoms as string;

  const [messages, setMessages] = useState<Message[]>([{
    id: '0',
    role: 'assistant',
    content: disease
      ? `नमस्ते! मुझे पता है आपकी फसल में **${disease}** है। इसके बारे में कुछ भी पूछें! 🌾`
      : 'नमस्ते! मैं आपका KisanAI सहायक हूँ 🌾\nफसल, मौसम, कीट, खाद — कुछ भी पूछें!',
    time: now(),
  }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const flatRef = useRef<FlatList>(null);

  function now() {
    return new Date().toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' });
  }

  const sendMessage = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, time: now() };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput('');
    setLoading(true);

    try {
      const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
      let reply = '';

      if (apiKey && apiKey !== 'your_anthropic_api_key_here') {
        const context = disease ? `रोग संदर्भ: ${disease}. लक्षण: ${symptoms || ''}` : '';
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model: 'claude-opus-4-6',
            max_tokens: 512,
            system: SYSTEM_PROMPT + (context ? `\n${context}` : ''),
            messages: updated
              .filter(m => m.id !== '0')
              .map(m => ({ role: m.role, content: m.content })),
          }),
        });
        if (res.ok) {
          const data = await res.json();
          reply = data.content[0].text;
        }
      }

      if (!reply) {
        reply = getDemoReply(text);
      }

      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: reply, time: now() };
      setMessages(prev => [...prev, aiMsg]);

      // Speak response
      if (Platform.OS !== 'web') {
        setIsSpeaking(true);
        Speech.speak(reply.slice(0, 200), {
          language: 'hi-IN', rate: 0.85,
          onDone: () => setIsSpeaking(false),
          onStopped: () => setIsSpeaking(false),
        });
      }
    } catch {
      const errMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '⚠️ माफ करें, जवाब देने में समस्या हुई। इंटरनेट जाँचें।',
        time: now(),
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  function getDemoReply(q: string) {
    if (q.includes('पीला') || q.includes('पत्ते')) return '🌿 पत्तियों का पीलापन नाइट्रोजन की कमी या पत्ती झुलसा रोग के कारण हो सकता है। मैन्कोज़ेब 2 ग्राम/लीटर का छिड़काव करें और यूरिया खाद डालें। 7 दिन में सुधार आएगा।';
    if (q.includes('खाद') || q.includes('fertilizer')) return '🌾 गेहूँ के लिए: बुआई के समय DAP 50 किलो/हेक्टेयर, एक माह बाद यूरिया 65 किलो/हेक्टेयर। पोटाश और जिंक भी फायदेमंद हैं।';
    if (q.includes('बारिश') || q.includes('सिंचाई')) return '🌧️ कल बारिश की संभावना है तो आज सिंचाई की जरूरत नहीं। खाद और कीटनाशक बारिश के 2 दिन बाद डालें — वरना बह जाएंगे।';
    if (q.includes('मक्खी') || q.includes('कीट')) return '🪰 सफेद मक्खी के लिए: इमिडाक्लोप्रिड 0.5 मिलीलीटर/लीटर या थायमेथॉक्सम 0.2 ग्राम/लीटर का छिड़काव करें। पीले चिपचिपे ट्रैप भी लगाएँ।';
    if (q.includes('PM-KISAN') || q.includes('योजना')) return '💰 PM-KISAN योजना में हर साल ₹6,000 की सहायता मिलती है — तीन किश्तों में। pmkisan.gov.in पर ऑनलाइन आवेदन करें या नजदीकी CSC जाएँ।';
    return '🤝 आपका सवाल समझ गया। कृपया अधिक जानकारी दें जैसे: कौन सी फसल, कौन से लक्षण, कितने समय से — तो मैं सटीक सलाह दे सकूँगा।';
  }

  useEffect(() => {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages]);

  const renderMsg = ({ item }: { item: Message }) => {
    const isUser = item.role === 'user';
    return (
      <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
        {!isUser && <View style={styles.aiAvatar}><Text style={{ fontSize: 18 }}>🌾</Text></View>}
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAI]}>
          <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>{item.content}</Text>
          <Text style={[styles.bubbleTime, isUser && { color: 'rgba(255,255,255,.5)' }]}>{item.time}</Text>
        </View>
        {isUser && <View style={styles.userAvatar}><Text style={{ fontSize: 18 }}>🧑‍🌾</Text></View>}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>🤖 KisanAI सहायक</Text>
          <Text style={styles.headerSub}>{isSpeaking ? '🔊 बोल रहा है...' : '● ऑनलाइन'}</Text>
        </View>
        <TouchableOpacity onPress={() => { Speech.stop(); setIsSpeaking(false); }} style={styles.muteBtn}>
          <Text style={{ fontSize: 20 }}>{isSpeaking ? '🔇' : '🔊'}</Text>
        </TouchableOpacity>
      </View>

      {/* Quick questions */}
      <View style={styles.quickRow}>
        <FlatList
          data={QUICK_QUESTIONS}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(i, idx) => String(idx)}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.qqChip} onPress={() => sendMessage(item)}>
              <Text style={styles.qqText}>{item}</Text>
            </TouchableOpacity>
          )}
          contentContainerStyle={{ paddingHorizontal: 12, gap: 8 }}
        />
      </View>

      {/* Messages */}
      <FlatList
        ref={flatRef}
        data={messages}
        keyExtractor={(m) => m.id}
        renderItem={renderMsg}
        contentContainerStyle={styles.msgList}
        onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: true })}
        ListFooterComponent={loading ? (
          <View style={[styles.msgRow]}>
            <View style={styles.aiAvatar}><Text style={{ fontSize: 18 }}>🌾</Text></View>
            <View style={[styles.bubble, styles.bubbleAI, { paddingVertical: 16 }]}>
              <ActivityIndicator size="small" color={Colors.primary} />
            </View>
          </View>
        ) : null}
      />

      {/* Input */}
      <View style={styles.inputArea}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="कोई भी सवाल पूछें..."
          placeholderTextColor={Colors.textMuted}
          multiline
          returnKeyType="send"
          onSubmitEditing={() => sendMessage(input)}
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!input.trim() || loading) && styles.sendBtnDisabled]}
          onPress={() => sendMessage(input)}
          disabled={!input.trim() || loading}
        >
          <Text style={styles.sendIcon}>➤</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f0' },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingTop: Platform.OS === 'ios' ? 54 : 32,
    paddingHorizontal: 14, paddingBottom: 14,
    backgroundColor: Colors.darkMid,
  },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,.15)', alignItems: 'center', justifyContent: 'center' },
  backText: { color: '#fff', fontSize: 20 },
  headerInfo: { flex: 1 },
  headerTitle: { color: '#fff', fontSize: 16, fontWeight: '800' },
  headerSub: { color: Colors.primaryLight, fontSize: 12, fontWeight: '600', marginTop: 1 },
  muteBtn: { padding: 6 },
  quickRow: { backgroundColor: '#fff', paddingVertical: 10, borderBottomWidth: 1, borderColor: Colors.border },
  qqChip: {
    backgroundColor: Colors.primaryBg, borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 7,
    borderWidth: 1, borderColor: Colors.border,
  },
  qqText: { fontSize: 12, fontWeight: '600', color: Colors.primaryDark },
  msgList: { padding: 14, gap: 12, paddingBottom: 12 },
  msgRow: { flexDirection: 'row', gap: 8, maxWidth: '85%', alignSelf: 'flex-start' },
  msgRowUser: { alignSelf: 'flex-end', flexDirection: 'row-reverse' },
  aiAvatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  userAvatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: Colors.secondary, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  bubble: {
    backgroundColor: '#fff', borderRadius: 18, padding: 12,
    maxWidth: '90%',
    elevation: 1, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4,
  },
  bubbleAI: { borderTopLeftRadius: 4 },
  bubbleUser: { backgroundColor: Colors.primary, borderTopRightRadius: 4 },
  bubbleText: { fontSize: 14, color: Colors.textPrimary, lineHeight: 20 },
  bubbleTextUser: { color: '#fff' },
  bubbleTime: { fontSize: 10, color: Colors.textMuted, marginTop: 4, alignSelf: 'flex-end' },
  inputArea: {
    flexDirection: 'row', gap: 10, alignItems: 'flex-end',
    padding: 12, backgroundColor: '#fff',
    borderTopWidth: 1, borderColor: Colors.border,
    paddingBottom: Platform.OS === 'ios' ? 28 : 12,
  },
  input: {
    flex: 1, backgroundColor: Colors.background,
    borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10,
    fontSize: 14, color: Colors.textPrimary,
    maxHeight: 100, borderWidth: 1.5, borderColor: Colors.border,
  },
  sendBtn: {
    width: 46, height: 46, borderRadius: 23,
    backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  sendBtnDisabled: { opacity: 0.4 },
  sendIcon: { color: '#fff', fontSize: 18 },
});
